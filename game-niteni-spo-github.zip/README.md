# Game Interaktif Kalimat S-P-O Anak SD (Niteni, Nirokke, Nambahi)

Media pembelajaran interaktif Bahasa Indonesia untuk siswa Sekolah Dasar tentang pola kalimat **Subjek - Predikat - Objek (S-P-O)** dengan pendekatan **Tri-N (*Niteni, Nirokke, Nambahi*)** yang terdiri atas **8 Slide Lengkap** beserta narator suara perempuan Bahasa Indonesia.

## Struktur File Repository
```text
├── index.html          # File utama aplikasi web (langsung dibuka oleh GitHub Pages)
├── assets/             # Folder seluruh gambar ilustrasi, papan kayu, kartu, dan tombol
├── .nojekyll           # Konfigurasi agar GitHub Pages memuat seluruh aset statis dengan cepat
└── README.md           # Dokumentasi & panduan penggunaan
```

## Cara Upload ke GitHub & Mengaktifkan Link GitHub Pages
1. **Ekstrak (Unzip)** file `game-niteni-spo-github.zip` ini di komputer/HP Anda.
2. Buka [github.com](https://github.com) lalu buat repository baru (**New repository**), misalnya beri nama `game-kalimat-spo`.
3. Klik **uploading an existing file** (atau **Add file** → **Upload files**).
4. Tarik (*drag and drop*) seluruh isi hasil ekstrak (`index.html`, folder `assets`, `README.md`, dan `.nojekyll`) ke halaman GitHub, lalu klik **Commit changes**.
5. Untuk mendapatkan link web yang bisa dimainkan online (**GitHub Pages**):
   - Buka menu **Settings** → **Pages** di repository GitHub Anda.
   - Pada bagian **Branch**, pilih `main` (atau `master`) dan folder `/ (root)`, lalu klik **Save**.
   - Tunggu sekitar 1 menit, maka game dapat langsung dimainkan melalui link `https://<username-github-anda>.github.io/<nama-repo>/`.
